# ============================================================
# Subject-level post-retraction citation analysis
#
# Inclusion criterion:
# Subjects with at least 100 retracted papers
#
# Outcomes:
# 1. Top 10 Subjects by proportion with Postcite > 0
# 2. Top 10 Subjects by mean Postcite
# ============================================================


# ------------------------------------------------------------
# 0. Packages
# ------------------------------------------------------------

packages <- c(
  "readxl",
  "dplyr",
  "ggplot2",
  "forcats",
  "scales",
  "patchwork",
  "writexl"
)

new_packages <- packages[
  !(packages %in% installed.packages()[, "Package"])
]

if (length(new_packages) > 0) {
  install.packages(new_packages)
}

library(readxl)
library(dplyr)
library(ggplot2)
library(forcats)
library(scales)
library(patchwork)
library(writexl)


# ------------------------------------------------------------
# 1. Read data
# ------------------------------------------------------------

dat <- read_excel(
  "D:/RCdata/20260705.xlsx"
)


# ------------------------------------------------------------
# 2. Clean data
# ------------------------------------------------------------

dat2 <- dat %>%
  dplyr::mutate(
    
    Subject =
      trimws(
        as.character(Subject)
      ),
    
    Postcite =
      suppressWarnings(
        as.numeric(Postcite)
      )
  ) %>%
  
  dplyr::filter(
    
    !is.na(Subject),
    
    Subject != "",
    
    !is.na(Postcite),
    
    Postcite >= 0
  )


cat(
  "Total papers =",
  nrow(dat2),
  "\n"
)

cat(
  "Total Subject categories =",
  dplyr::n_distinct(dat2$Subject),
  "\n"
)


# ============================================================
# 3. Calculate Subject-level statistics
# ============================================================

subject_summary <- dat2 %>%
  
  dplyr::group_by(
    Subject
  ) %>%
  
  dplyr::summarise(
    
    # Total number of retracted papers
    Total_retracted =
      dplyr::n(),
    
    # Papers with at least one citation after retraction
    Post_positive =
      sum(
        Postcite > 0,
        na.rm = TRUE
      ),
    
    # Percentage with Postcite > 0
    Post_positive_percent =
      Post_positive /
      Total_retracted *
      100,
    
    # Mean Postcite including zeros
    Mean_Postcite =
      mean(
        Postcite,
        na.rm = TRUE
      ),
    
    # Median for supplementary inspection
    Median_Postcite =
      median(
        Postcite,
        na.rm = TRUE
      ),
    
    .groups = "drop"
  )


# ============================================================
# 4. Exclude Subjects with fewer than 100 records
# ============================================================

subject_summary_N100 <- subject_summary %>%
  
  dplyr::filter(
    Total_retracted >= 100
  )


cat(
  "Subjects with N >= 100 =",
  nrow(subject_summary_N100),
  "\n"
)


# ============================================================
# 5. Top 10 by proportion with Postcite > 0
# ============================================================

top10_probability <- subject_summary_N100 %>%
  
  dplyr::arrange(
    dplyr::desc(Post_positive_percent),
    dplyr::desc(Total_retracted)
  ) %>%
  
  dplyr::slice_head(
    n = 10
  ) %>%
  
  dplyr::mutate(
    Rank =
      dplyr::row_number()
  )


print(top10_probability)


# ============================================================
# 6. Top 10 by mean Postcite
# ============================================================

top10_mean <- subject_summary_N100 %>%
  
  dplyr::arrange(
    dplyr::desc(Mean_Postcite),
    dplyr::desc(Total_retracted)
  ) %>%
  
  dplyr::slice_head(
    n = 10
  ) %>%
  
  dplyr::mutate(
    Rank =
      dplyr::row_number()
  )


print(top10_mean)


# ============================================================
# 7. Prepare Panel a
# ============================================================

plot_prob <- top10_probability %>%
  
  dplyr::mutate(
    
    Subject =
      forcats::fct_reorder(
        Subject,
        Post_positive_percent
      ),
    
    Label =
      paste0(
        sprintf(
          "%.1f",
          Post_positive_percent
        ),
        "%"
      )
  )


# ============================================================
# 8. Panel a:
#    proportion with Postcite > 0
# ============================================================

p1 <- ggplot(
  plot_prob,
  aes(
    x = Post_positive_percent,
    y = Subject
  )
) +
  
  geom_col(
    width = 0.68,
    fill = "#4C78A8"
  ) +
  
  geom_text(
    aes(
      label = Label
    ),
    hjust = -0.12,
    size = 3.4
  ) +
  
  scale_x_continuous(
    
    limits = c(
      0,
      max(
        plot_prob$Post_positive_percent
      ) * 1.12
    ),
    
    breaks =
      seq(
        0,
        100,
        20
      ),
    
    labels =
      function(x) {
        paste0(
          x,
          "%"
        )
      },
    
    expand =
      expansion(
        mult = c(
          0,
          0.02
        )
      )
  ) +
  
  labs(
    
    tag = "a",
    
    x =
      "Retracted papers cited after retraction (%)",
    
    y = NULL
  ) +
  
  theme_classic(
    base_size = 11
  ) +
  
  theme(
    
    axis.line.y =
      element_blank(),
    
    axis.ticks.y =
      element_blank(),
    
    plot.tag =
      element_text(
        face = "bold",
        size = 13
      )
  )


# ============================================================
# 9. Prepare Panel b
# ============================================================

plot_mean <- top10_mean %>%
  
  dplyr::mutate(
    
    Subject =
      forcats::fct_reorder(
        Subject,
        Mean_Postcite
      ),
    
    Label =
      sprintf(
        "%.1f",
        Mean_Postcite
      )
  )


# ============================================================
# 10. Panel b:
#     mean Postcite
# ============================================================

p2 <- ggplot(
  plot_mean,
  aes(
    x = Mean_Postcite,
    y = Subject
  )
) +
  
  geom_col(
    width = 0.68,
    fill = "#F28E2B"
  ) +
  
  geom_text(
    aes(
      label = Label
    ),
    hjust = -0.12,
    size = 3.4
  ) +
  
  scale_x_continuous(
    
    limits = c(
      0,
      max(
        plot_mean$Mean_Postcite
      ) * 1.15
    ),
    
    expand =
      expansion(
        mult = c(
          0,
          0.02
        )
      )
  ) +
  
  labs(
    
    tag = "b",
    
    x =
      "Mean post-retraction citations per paper",
    
    y = NULL
  ) +
  
  theme_classic(
    base_size = 11
  ) +
  
  theme(
    
    axis.line.y =
      element_blank(),
    
    axis.ticks.y =
      element_blank(),
    
    plot.tag =
      element_text(
        face = "bold",
        size = 13
      )
  )


# ============================================================
# 11. Combine figures
# ============================================================

final_plot <-
  p1 |
  p2


print(final_plot)


# ============================================================
# 12. Save figure
# ============================================================

ggsave(
  
  filename =
    "Top10_Subject_Postcitation_N100.png",
  
  plot =
    final_plot,
  
  width = 11,
  
  height = 5.2,
  
  dpi = 600
)


ggsave(
  
  filename =
    "Top10_Subject_Postcitation_N100.pdf",
  
  plot =
    final_plot,
  
  width = 11,
  
  height = 5.2
)


# ============================================================
# 13. Export results
# ============================================================

write_xlsx(
  
  list(
    
    All_Subjects =
      subject_summary,
    
    Subjects_N100 =
      subject_summary_N100,
    
    Top10_probability_N100 =
      top10_probability,
    
    Top10_Mean_Postcite_N100 =
      top10_mean
  ),
  
  "Subject_Postcitation_statistics_N100.xlsx"
)


write.csv(
  
  top10_probability,
  
  "Top10_Subject_probability_N100.csv",
  
  row.names = FALSE
)


write.csv(
  
  top10_mean,
  
  "Top10_Subject_MeanPostcite_N100.csv",
  
  row.names = FALSE
)


cat(
  "\nAnalysis completed successfully.\n"
)