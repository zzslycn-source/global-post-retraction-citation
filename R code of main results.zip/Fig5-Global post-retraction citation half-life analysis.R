# ============================================================
# Global post-retraction citation half-life analysis
# Dataset: 20260705_Updated.xlsx
# Total retracted papers: 58,518
# ============================================================

# ------------------------------------------------------------
# 0. Load packages
# ------------------------------------------------------------

library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(ggplot2)


# ------------------------------------------------------------
# 1. Read data
# ------------------------------------------------------------

dat <- read_excel("D:/RCdata/20260705_Updated.xlsx")

cat("============================================\n")
cat("Original dataset\n")
cat("============================================\n")

cat("Total rows:", nrow(dat), "\n")
cat("Unique papers:", n_distinct(dat$ID), "\n\n")


# ------------------------------------------------------------
# 2. Identify annual citation columns
# ------------------------------------------------------------

year_cols <- names(dat)[str_detect(names(dat), "^Y\\d{4}$")]

citation_years <- as.numeric(
  str_remove(year_cols, "^Y")
)

# Exclude 2026 because the year is incomplete
year_cols <- year_cols[citation_years <= 2025]

citation_years <- as.numeric(
  str_remove(year_cols, "^Y")
)

cat("Citation years used:",
    min(citation_years),
    "to",
    max(citation_years),
    "\n\n")


# ------------------------------------------------------------
# 3. Standardize variables
# ------------------------------------------------------------

dat <- dat %>%
  mutate(
    ID = as.character(ID),
    RetY = as.numeric(RetY),
    Subject = as.character(Subject),
    Precite = as.numeric(Precite),
    Postcite = as.numeric(Postcite)
  )


# ------------------------------------------------------------
# 4. Reshape annual citation data
# ------------------------------------------------------------

long <- dat %>%
  select(
    ID,
    RetY,
    Subject,
    Precite,
    Postcite,
    all_of(year_cols)
  ) %>%
  pivot_longer(
    cols = all_of(year_cols),
    names_to = "Year",
    values_to = "Cite"
  ) %>%
  mutate(
    Year = as.numeric(str_remove(Year, "^Y")),
    Cite = as.numeric(Cite),
    
    # Years since retraction
    t = Year - RetY
  ) %>%
  filter(
    !is.na(RetY),
    t >= 1,
    Year <= 2025
  )


# ------------------------------------------------------------
# 5. Define the complete 10-year observation cohort
#
# Retraction in 2015 or earlier
# → complete years t = 1,...,10
# → observation through 2025
# ------------------------------------------------------------

analysis_ids <- dat %>%
  filter(
    !is.na(RetY),
    RetY <= 2015
  ) %>%
  distinct(ID, RetY)


# ------------------------------------------------------------
# 6. IMPORTANT:
#    Report exactly why the sample becomes 15,728
# ------------------------------------------------------------

cat("============================================\n")
cat("Sample size check\n")
cat("============================================\n")

cat(
  "Total papers in original dataset:",
  n_distinct(dat$ID),
  "\n"
)

cat(
  "Papers with known retraction year:",
  n_distinct(dat$ID[!is.na(dat$RetY)]),
  "\n"
)

cat(
  "Papers retracted in or before 2015:",
  n_distinct(analysis_ids$ID),
  "\n\n"
)


# ------------------------------------------------------------
# 7. Create 10-year analysis dataset
# ------------------------------------------------------------

analysis_long <- long %>%
  filter(
    ID %in% analysis_ids$ID,
    t >= 1,
    t <= 10
  )


cat(
  "Unique papers entering 10-year citation-decay analysis:",
  n_distinct(analysis_long$ID),
  "\n\n"
)


# ------------------------------------------------------------
# 8. Check the distribution of retraction years
# ------------------------------------------------------------

retraction_summary <- dat %>%
  filter(!is.na(RetY)) %>%
  count(RetY, name = "N") %>%
  arrange(RetY)

print(retraction_summary)


# ------------------------------------------------------------
# 9. Calculate population-level annual citation intensity
# ------------------------------------------------------------
#
# MeanCite = mean annual citations across the entire
# retracted-paper population.
#
# IMPORTANT:
# Zero citations are retained.
#
# If blank cells in the original Excel file explicitly mean
# zero citations, uncomment the following line:
#
# analysis_long <- analysis_long %>%
#     mutate(Cite = replace_na(Cite, 0))
#
# Otherwise, NA values remain missing rather than being
# incorrectly converted to zero.
# ------------------------------------------------------------

global_decay <- analysis_long %>%
  group_by(t) %>%
  summarise(
    N_papers = n_distinct(ID),
    
    N_valid = sum(!is.na(Cite)),
    
    N_zero = sum(
      Cite == 0,
      na.rm = TRUE
    ),
    
    MeanCite = mean(
      Cite,
      na.rm = TRUE
    ),
    
    SD = sd(
      Cite,
      na.rm = TRUE
    ),
    
    SE = SD / sqrt(N_valid),
    
    .groups = "drop"
  )


print(global_decay)


# ------------------------------------------------------------
# 10. Exponential decay model
# ------------------------------------------------------------
#
# MeanCite = A * exp(-k * t)
#
# Half-life = ln(2) / k
# ------------------------------------------------------------

global_fit <- nls(
  MeanCite ~ A * exp(-k * t),
  data = global_decay,
  start = list(
    A = max(global_decay$MeanCite, na.rm = TRUE),
    k = 0.10
  ),
  control = nls.control(
    maxiter = 1000,
    warnOnly = TRUE
  )
)


# ------------------------------------------------------------
# 11. Extract model parameters
# ------------------------------------------------------------

global_coef <- coef(global_fit)

A_global <- unname(
  global_coef["A"]
)

k_global <- unname(
  global_coef["k"]
)

global_half_life <- log(2) / k_global


# ------------------------------------------------------------
# 12. Calculate R2
# ------------------------------------------------------------

global_decay <- global_decay %>%
  mutate(
    Predicted = predict(
      global_fit,
      newdata = global_decay
    ),
    
    Residual = MeanCite - Predicted
  )


SS_res <- sum(
  global_decay$Residual^2,
  na.rm = TRUE
)

SS_tot <- sum(
  (
    global_decay$MeanCite -
      mean(
        global_decay$MeanCite,
        na.rm = TRUE
      )
  )^2,
  na.rm = TRUE
)

R2_global <- 1 - SS_res / SS_tot


# ------------------------------------------------------------
# 13. Print final global results
# ------------------------------------------------------------

cat("\n============================================\n")
cat("GLOBAL POST-RETRACTION CITATION DECAY\n")
cat("============================================\n")

cat(
  "Total retracted papers:",
  n_distinct(dat$ID),
  "\n"
)

cat(
  "Papers in 10-year analysis:",
  n_distinct(analysis_long$ID),
  "\n"
)

cat(
  "A =",
  round(A_global, 4),
  "\n"
)

cat(
  "k =",
  round(k_global, 4),
  "\n"
)

cat(
  "Half-life =",
  round(global_half_life, 3),
  "years\n"
)

cat(
  "R2 =",
  round(R2_global, 4),
  "\n"
)

cat(
  "Model: MeanCite =",
  round(A_global, 4),
  "* exp(-",
  round(k_global, 4),
  "* t)\n"
)

cat("============================================\n\n")


# ------------------------------------------------------------
# 14. Create smooth fitted curve
# ------------------------------------------------------------

global_pred <- data.frame(
  t = seq(
    min(global_decay$t),
    max(global_decay$t),
    length.out = 300
  )
)

global_pred$Fit <- predict(
  global_fit,
  newdata = global_pred
)


# ------------------------------------------------------------
# 15. Create annotation text
# ------------------------------------------------------------

equation_text <- paste0(
  "y = ",
  formatC(
    A_global,
    format = "f",
    digits = 3
  ),
  " exp(-",
  formatC(
    k_global,
    format = "f",
    digits = 3
  ),
  "t)"
)

r2_text <- paste0(
  "R² = ",
  formatC(
    R2_global,
    format = "f",
    digits = 3
  )
)

half_text <- paste0(
  "T₁/₂ = ",
  formatC(
    global_half_life,
    format = "f",
    digits = 2
  ),
  " years"
)

n_text <- paste0(
  "N = ",
  format(
    n_distinct(analysis_long$ID),
    big.mark = ","
  )
)

annotation_text <- paste(
  equation_text,
  r2_text,
  half_text,
  n_text,
  sep = "\n"
)


# ------------------------------------------------------------
# 16. Global citation decay figure
# ------------------------------------------------------------

p_global <- ggplot() +
  
  # Observed population mean
  geom_point(
    data = global_decay,
    aes(
      x = t,
      y = MeanCite
    ),
    size = 3
  ) +
  
  # Observed trajectory
  geom_line(
    data = global_decay,
    aes(
      x = t,
      y = MeanCite
    ),
    linewidth = 0.8
  ) +
  
  # Exponential fitted curve
  geom_line(
    data = global_pred,
    aes(
      x = t,
      y = Fit
    ),
    linewidth = 1.3,
    linetype = "dashed"
  ) +
  
  # Formula + R2 + half-life + sample size
  annotate(
    "text",
    x = 6.2,
    y = max(global_decay$MeanCite, na.rm = TRUE) * 0.85,
    label = annotation_text,
    hjust = 0,
    vjust = 1,
    size = 4.5
  ) +
  
  labs(
    x = "Years since retraction",
    y = "Mean annual citations",
    title = "Global post-retraction citation decay"
  ) +
  
  scale_x_continuous(
    breaks = 1:10
  ) +
  
  theme_classic(
    base_size = 14
  )


print(p_global)


# ------------------------------------------------------------
# 17. Save global figure
# ------------------------------------------------------------

ggsave(
  filename = "Global_Post_Retraction_Citation_Decay.png",
  plot = p_global,
  width = 8,
  height = 6,
  dpi = 600
)


# ============================================================
# 18. TOP 10 DISCIPLINES
# ============================================================

# First identify the ten disciplines with the largest
# numbers of retracted papers.

top10_by_N <- dat %>%
  filter(!is.na(Subject)) %>%
  count(
    Subject,
    sort = TRUE
  ) %>%
  slice_head(n = 10) %>%
  pull(Subject)


cat("\n============================================\n")
cat("Top 10 disciplines by sample size\n")
cat("============================================\n")

print(top10_by_N)


# ------------------------------------------------------------
# 19. Discipline-level citation decay
# ------------------------------------------------------------

subject_decay <- analysis_long %>%
  filter(
    Subject %in% top10_by_N
  ) %>%
  group_by(
    Subject,
    t
  ) %>%
  summarise(
    N_papers = n_distinct(ID),
    
    N_valid = sum(!is.na(Cite)),
    
    MeanCite = mean(
      Cite,
      na.rm = TRUE
    ),
    
    .groups = "drop"
  )


# ------------------------------------------------------------
# 20. Fit exponential model to each discipline
# ------------------------------------------------------------

subject_results <- subject_decay %>%
  group_by(Subject) %>%
  group_modify(
    ~ {
      
      dat_sub <- .x
      
      # Need at least 3 time points
      if (nrow(dat_sub) < 3) {
        return(
          tibble(
            A = NA_real_,
            k = NA_real_,
            HalfLife = NA_real_,
            R2 = NA_real_
          )
        )
      }
      
      fit <- tryCatch(
        
        nls(
          MeanCite ~ A * exp(-k * t),
          data = dat_sub,
          start = list(
            A = max(
              dat_sub$MeanCite,
              na.rm = TRUE
            ),
            k = 0.10
          ),
          control = nls.control(
            maxiter = 1000,
            warnOnly = TRUE
          )
        ),
        
        error = function(e) NULL
      )
      
      if (is.null(fit)) {
        
        return(
          tibble(
            A = NA_real_,
            k = NA_real_,
            HalfLife = NA_real_,
            R2 = NA_real_
          )
        )
        
      }
      
      coef_fit <- coef(fit)
      
      A <- unname(
        coef_fit["A"]
      )
      
      k <- unname(
        coef_fit["k"]
      )
      
      half_life <- log(2) / k
      
      predicted <- predict(
        fit,
        newdata = dat_sub
      )
      
      residual <- dat_sub$MeanCite - predicted
      
      SS_res <- sum(
        residual^2,
        na.rm = TRUE
      )
      
      SS_tot <- sum(
        (
          dat_sub$MeanCite -
            mean(
              dat_sub$MeanCite,
              na.rm = TRUE
            )
        )^2,
        na.rm = TRUE
      )
      
      R2 <- 1 - SS_res / SS_tot
      
      tibble(
        A = A,
        k = k,
        HalfLife = half_life,
        R2 = R2
      )
    }
  ) %>%
  ungroup() %>%
  arrange(
    desc(HalfLife)
  )


# ------------------------------------------------------------
# 21. Add sample size of each discipline
# ------------------------------------------------------------

subject_N <- dat %>%
  filter(
    Subject %in% top10_by_N
  ) %>%
  group_by(
    Subject
  ) %>%
  summarise(
    N_total = n_distinct(ID),
    .groups = "drop"
  )


subject_results <- subject_results %>%
  left_join(
    subject_N,
    by = "Subject"
  ) %>%
  arrange(
    desc(HalfLife)
  )


# ------------------------------------------------------------
# 22. Print discipline results
# ------------------------------------------------------------

cat("\n============================================\n")
cat("Discipline-specific half-lives\n")
cat("============================================\n")

print(subject_results)


# ------------------------------------------------------------
# 23. Discipline half-life bar plot
# ------------------------------------------------------------

subject_results <- subject_results %>%
  mutate(
    Subject = reorder(
      Subject,
      HalfLife
    )
  )


p_subject <- ggplot(
  subject_results,
  aes(
    x = HalfLife,
    y = Subject
  )
) +
  
  geom_col(
    width = 0.7
  ) +
  
  geom_text(
    aes(
      label = paste0(
        round(HalfLife, 2),
        " y"
      )
    ),
    hjust = -0.1,
    size = 4
  ) +
  
  labs(
    x = "Post-retraction citation half-life (years)",
    y = NULL,
    title = "Post-retraction citation half-life across major disciplines"
  ) +
  
  scale_x_continuous(
    expand = expansion(
      mult = c(0, 0.15)
    )
  ) +
  
  theme_classic(
    base_size = 14
  )


print(p_subject)


# ------------------------------------------------------------
# 24. Save discipline figure
# ------------------------------------------------------------

ggsave(
  filename = "Discipline_Post_Retraction_Half_Life.png",
  plot = p_subject,
  width = 9,
  height = 6,
  dpi = 600
)


# ------------------------------------------------------------
# 25. Export results
# ------------------------------------------------------------

write.csv(
  global_decay,
  "Global_Citation_Decay_Data.csv",
  row.names = FALSE
)

write.csv(
  subject_results,
  "Discipline_Half_Life_Results.csv",
  row.names = FALSE
)