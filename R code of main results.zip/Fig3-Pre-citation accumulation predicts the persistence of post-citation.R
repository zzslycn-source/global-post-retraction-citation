# ============================================================
# Precite vs Postcite
# Updated analysis based on 20260705.xlsx
# ============================================================

# ----------------------------
# 0. Packages
# ----------------------------
packages <- c(
  "readxl",
  "dplyr",
  "ggplot2",
  "broom",
  "patchwork",
  "scales",
  "hexbin"
)

new_packages <- packages[
  !(packages %in% installed.packages()[, "Package"])
]

if (length(new_packages) > 0) {
  install.packages(new_packages)
}

library(readxl)
library(dplyr)
library(ggplot2)
library(broom)
library(patchwork)
library(scales)
library(hexbin)

# ----------------------------
# 1. Read data
# ----------------------------
dat <- read_excel("D:/RCdata/20260705.xlsx")

dat <- dat %>%
  dplyr::mutate(
    Precite = as.numeric(Precite),
    Postcite = as.numeric(Postcite)
  ) %>%
  dplyr::filter(
    !is.na(Precite),
    !is.na(Postcite),
    Precite >= 0,
    Postcite >= 0
  )

cat("Total N =", nrow(dat), "\n")

# ----------------------------
# 2. Spearman correlations
# ----------------------------
cor_full <- cor.test(
  dat$Precite,
  dat$Postcite,
  method = "spearman",
  exact = FALSE
)

dat_pre_pos <- dat %>%
  dplyr::filter(Precite > 0)

cor_pre_pos <- cor.test(
  dat_pre_pos$Precite,
  dat_pre_pos$Postcite,
  method = "spearman",
  exact = FALSE
)

dat_excl_both0 <- dat %>%
  dplyr::filter(!(Precite == 0 & Postcite == 0))

cor_excl_both0 <- cor.test(
  dat_excl_both0$Precite,
  dat_excl_both0$Postcite,
  method = "spearman",
  exact = FALSE
)

cat("Full sample rho =", cor_full$estimate, "\n")
cat("Precite > 0 rho =", cor_pre_pos$estimate, "\n")
cat("Exclude both zero rho =", cor_excl_both0$estimate, "\n")

# ----------------------------
# 3. Logistic regression
# ----------------------------
dat <- dat %>%
  dplyr::mutate(
    logPre = log1p(Precite),
    Post_any = ifelse(Postcite > 0, 1, 0)
  )

model_logit <- glm(
  Post_any ~ logPre,
  data = dat,
  family = binomial(link = "logit")
)

logit_result <- broom::tidy(
  model_logit,
  conf.int = TRUE,
  exponentiate = TRUE
)

print(logit_result)

OR_Pre <- logit_result %>%
  dplyr::filter(term == "logPre")

# ----------------------------
# 4. Grouped summary for probability plot
# ----------------------------
dat <- dat %>%
  dplyr::mutate(
    Pre_group = cut(
      Precite,
      breaks = c(-Inf, 0, 1, 5, 10, 50, 100, 500, Inf),
      labels = c("0", "1", "2–5", "6–10", "11–50", "51–100", "101–500", ">500"),
      ordered_result = TRUE
    )
  )

group_summary <- dat %>%
  dplyr::group_by(Pre_group) %>%
  dplyr::summarise(
    N = dplyr::n(),
    Positive = sum(Post_any),
    Prob = mean(Post_any),
    Pre_median = median(Precite),
    .groups = "drop"
  )

# Wilson CI
wilson_ci <- function(x, n, z = 1.96) {
  p <- x / n
  denom <- 1 + z^2 / n
  centre <- (p + z^2 / (2 * n)) / denom
  half <- z * sqrt(p * (1 - p) / n + z^2 / (4 * n^2)) / denom
  c(lower = centre - half, upper = centre + half)
}

cis <- mapply(
  wilson_ci,
  group_summary$Positive,
  group_summary$N,
  SIMPLIFY = FALSE
)

group_summary$CI_low <- sapply(cis, function(x) x["lower"])
group_summary$CI_high <- sapply(cis, function(x) x["upper"])

print(group_summary)

# ----------------------------
# 5. Prediction grid for logistic curve
# ----------------------------
pred_grid <- data.frame(
  Precite = exp(seq(log(1), log(max(dat$Precite) + 1), length.out = 300)) - 1
)

pred_grid$logPre <- log1p(pred_grid$Precite)

pred <- predict(
  model_logit,
  newdata = pred_grid,
  type = "link",
  se.fit = TRUE
)

pred_grid <- pred_grid %>%
  dplyr::mutate(
    eta = pred$fit,
    eta_low = eta - 1.96 * pred$se.fit,
    eta_high = eta + 1.96 * pred$se.fit,
    prob = plogis(eta),
    prob_low = plogis(eta_low),
    prob_high = plogis(eta_high)
  )

# ----------------------------
# 6. Panel a: Hexbin correlation plot
# ----------------------------
p1 <- ggplot(dat, aes(x = log1p(Precite), y = log1p(Postcite))) +
  geom_hex(bins = 55) +
  scale_fill_viridis_c(trans = "log10", name = "Papers") +
  labs(
    tag = "a",
    x = "ln(1 + pre-retraction citations)",
    y = "ln(1 + post-retraction citations)"
  ) +
  annotate(
    "text",
    x = 0.2,
    y = max(log1p(dat$Postcite), na.rm = TRUE) * 0.96,
    hjust = 0,
    vjust = 1,
    size = 3.6,
    label = paste0(
      "Spearman's \u03C1 = ", sprintf("%.3f", cor_full$estimate), ", P < 0.001\n",
      "Pre > 0: \u03C1 = ", sprintf("%.3f", cor_pre_pos$estimate), ", P < 0.001\n",
      "Exclude both zero: \u03C1 = ", sprintf("%.3f", cor_excl_both0$estimate), ", P < 0.001"
    )
  ) +
  theme_classic(base_size = 11) +
  theme(
    plot.tag = element_text(face = "bold", size = 13)
  )

# ----------------------------
# 7. Panel b: Probability plot with logistic fit
# ----------------------------
p2 <- ggplot() +
  geom_ribbon(
    data = pred_grid,
    aes(x = Precite, ymin = prob_low * 100, ymax = prob_high * 100),
    alpha = 0.18
  ) +
  geom_line(
    data = pred_grid,
    aes(x = Precite, y = prob * 100),
    linewidth = 0.9
  ) +
  geom_errorbar(
    data = group_summary,
    aes(x = Pre_median, ymin = CI_low * 100, ymax = CI_high * 100),
    width = 0,
    linewidth = 0.55
  ) +
  geom_point(
    data = group_summary,
    aes(x = Pre_median, y = Prob * 100),
    size = 2.7
  ) +
  scale_x_continuous(
    trans = pseudo_log_trans(base = 10, sigma = 1),
    breaks = c(0, 1, 5, 10, 50, 100, 500, 1000),
    labels = comma
  ) +
  scale_y_continuous(
    limits = c(0, 100),
    breaks = seq(0, 100, 25),
    labels = function(x) paste0(x, "%")
  ) +
  annotate(
    "text",
    x = 0,
    y = 98,
    hjust = 0,
    vjust = 1,
    size = 3.6,
    label = paste0(
      "OR = ", sprintf("%.2f", OR_Pre$estimate),
      " (95% CI ", sprintf("%.2f", OR_Pre$conf.low),
      "\u2013", sprintf("%.2f", OR_Pre$conf.high), ")\nP < 0.001"
    )
  ) +
  labs(
    tag = "b",
    x = "Pre-retraction citations",
    y = "Probability of post-retraction citation (%)"
  ) +
  theme_classic(base_size = 11) +
  theme(
    plot.tag = element_text(face = "bold", size = 13)
  )

# ----------------------------
# 8. Combine figure
# ----------------------------
final_plot <- p1 | p2

print(final_plot)

ggsave(
  "Precite_Postcite_relationship_updated.png",
  final_plot,
  width = 10,
  height = 4.5,
  dpi = 600
)

ggsave(
  "Precite_Postcite_relationship_updated.pdf",
  final_plot,
  width = 10,
  height = 4.5
)

# ----------------------------
# 9. Save outputs
# ----------------------------
write.csv(group_summary, "Precite_probability_groups_updated.csv", row.names = FALSE)
write.csv(logit_result, "Precite_logistic_updated.csv", row.names = FALSE)