# ============================================================
# Post-retraction citation persistence analysis
#
# Outcome:
#   Postcite > 0
#
# Main predictors:
#   International
#   Precite
#   jif
#   percentageOAGold
#
# Time structure:
#   T_pre   = publication -> retraction
#   T_post  = retraction -> 2026-02-28
#   T_total = publication -> 2026-02-28
#
# Main model:
#   Postcite ~
#     International * (Precite + JIF + Gold OA)
#     + T_pre
#     + offset(log(T_post))
#
# Model family:
#   Zero-truncated negative binomial
#
# T_total is calculated and reported, but is not simultaneously
# entered with T_pre and T_post because:
#
# T_total = T_pre + T_post
# ============================================================


# ============================================================
# 0. Install packages if needed
# ============================================================

packages <- c(
  "readxl",
  "dplyr",
  "lubridate",
  "ggplot2",
  "glmmTMB",
  "DHARMa",
  "broom.mixed",
  "patchwork",
  "writexl"
)

new_packages <- packages[
  !(packages %in% installed.packages()[, "Package"])
]

if (length(new_packages) > 0) {
  install.packages(new_packages)
}


# ============================================================
# 1. Load packages
# ============================================================

library(readxl)
library(dplyr)
library(lubridate)
library(ggplot2)
library(glmmTMB)
library(DHARMa)
library(broom.mixed)
library(patchwork)
library(writexl)


# ============================================================
# 2. Read data
# ============================================================

dat <- read_excel(
  "D:/RCdata/20260705_Updated.xlsx"
)

cat("Original sample size =", nrow(dat), "\n")


# ============================================================
# 3. Convert variable types
# ============================================================

dat2 <- dat %>%
  mutate(
    
    International = factor(
      International,
      levels = c(0, 1),
      labels = c(
        "Non-international",
        "International"
      )
    ),
    
    Precite =
      suppressWarnings(
        as.numeric(Precite)
      ),
    
    Postcite =
      suppressWarnings(
        as.numeric(Postcite)
      ),
    
    jif =
      suppressWarnings(
        as.numeric(jif)
      ),
    
    percentageOAGold =
      suppressWarnings(
        as.numeric(percentageOAGold)
      ),
    
    OriginalPaperDate =
      mdy_hm(
        as.character(OriginalPaperDate),
        quiet = TRUE
      ),
    
    RetractionDate =
      mdy_hm(
        as.character(RetractionDate),
        quiet = TRUE
      )
  )


# ============================================================
# 4. Define citation cutoff
# ============================================================
#
# 2026-02-28 24:00
# is equivalent to
# 2026-03-01 00:00
# ============================================================

citation_cutoff <-
  ymd_hms(
    "2026-03-01 00:00:00",
    tz = "UTC"
  )


# ============================================================
# 5. Calculate all three time intervals
# ============================================================

dat2 <- dat2 %>%
  mutate(
    
    # --------------------------------------------------------
    # Publication -> Retraction
    # --------------------------------------------------------
    
    T_pre_days =
      as.numeric(
        difftime(
          RetractionDate,
          OriginalPaperDate,
          units = "days"
        )
      ),
    
    T_pre_years =
      T_pre_days / 365.25,
    
    
    # --------------------------------------------------------
    # Retraction -> citation cutoff
    # --------------------------------------------------------
    
    T_post_days =
      as.numeric(
        difftime(
          citation_cutoff,
          RetractionDate,
          units = "days"
        )
      ),
    
    T_post_years =
      T_post_days / 365.25,
    
    
    # --------------------------------------------------------
    # Publication -> citation cutoff
    # --------------------------------------------------------
    
    T_total_days =
      as.numeric(
        difftime(
          citation_cutoff,
          OriginalPaperDate,
          units = "days"
        )
      ),
    
    T_total_years =
      T_total_days / 365.25
  )


# ============================================================
# 6. Check mathematical relationship between time variables
# ============================================================

time_check <- dat2 %>%
  mutate(
    Time_difference =
      T_total_years -
      T_pre_years -
      T_post_years
  )

summary(
  time_check$Time_difference
)

# This should be approximately zero.


# ============================================================
# 7. Check invalid dates
# ============================================================

cat(
  "Publication later than retraction =",
  sum(
    dat2$T_pre_years < 0,
    na.rm = TRUE
  ),
  "\n"
)

cat(
  "Retraction later than cutoff =",
  sum(
    dat2$T_post_years <= 0,
    na.rm = TRUE
  ),
  "\n"
)


# ============================================================
# 8. Construct analysis dataset
# ============================================================
#
# Current scientific question:
#
# Among papers that continued to receive citations after
# retraction, what factors are associated with the intensity
# of continued citation?
#
# Therefore:
# Postcite > 0
# ============================================================

post_dat <- dat2 %>%
  filter(
    
    Postcite > 0,
    
    !is.na(International),
    
    !is.na(Precite),
    
    !is.na(jif),
    
    !is.na(percentageOAGold),
    
    !is.na(T_pre_years),
    
    !is.na(T_post_years),
    
    !is.na(T_total_years),
    
    T_pre_years >= 0,
    
    T_post_years > 0
  )


cat(
  "\nFinal sample size =",
  nrow(post_dat),
  "\n"
)

cat(
  "\nInternational collaboration:\n"
)

print(
  table(post_dat$International)
)


# ============================================================
# 9. Descriptive statistics
# ============================================================

summary_all <- post_dat %>%
  summarise(
    
    N = n(),
    
    Postcite_mean =
      mean(Postcite),
    
    Postcite_median =
      median(Postcite),
    
    Precite_mean =
      mean(Precite),
    
    Precite_median =
      median(Precite),
    
    JIF_mean =
      mean(jif),
    
    JIF_median =
      median(jif),
    
    GoldOA_mean =
      mean(percentageOAGold),
    
    GoldOA_median =
      median(percentageOAGold),
    
    T_pre_mean =
      mean(T_pre_years),
    
    T_pre_median =
      median(T_pre_years),
    
    T_post_mean =
      mean(T_post_years),
    
    T_post_median =
      median(T_post_years),
    
    T_total_mean =
      mean(T_total_years),
    
    T_total_median =
      median(T_total_years)
  )


print(summary_all)


# ============================================================
# 10. Descriptive statistics by International
# ============================================================

summary_int <- post_dat %>%
  group_by(
    International
  ) %>%
  summarise(
    
    N = n(),
    
    Postcite_mean =
      mean(Postcite),
    
    Postcite_median =
      median(Postcite),
    
    Precite_mean =
      mean(Precite),
    
    Precite_median =
      median(Precite),
    
    JIF_mean =
      mean(jif),
    
    GoldOA_mean =
      mean(percentageOAGold),
    
    T_pre_mean =
      mean(T_pre_years),
    
    T_post_mean =
      mean(T_post_years),
    
    T_total_mean =
      mean(T_total_years),
    
    .groups = "drop"
  )

print(summary_int)


# ============================================================
# 11. Transform continuous predictors
# ============================================================
#
# Precite and JIF are strongly right-skewed.
#
# T_pre is also strongly right-skewed.
#
# Therefore use:
#
# log(1+x)
#
# followed by standardization.
#
# Gold OA:
# 0-100 -> proportion -> standardization
# ============================================================

post_dat <- post_dat %>%
  mutate(
    
    log_Precite =
      log1p(Precite),
    
    log_jif =
      log1p(jif),
    
    OA_prop =
      percentageOAGold / 100,
    
    log_Tpre =
      log1p(T_pre_years),
    
    log_Ttotal =
      log1p(T_total_years)
  )


# ============================================================
# 12. Standardize variables
# ============================================================

post_dat <- post_dat %>%
  mutate(
    
    z_Precite =
      as.numeric(
        scale(log_Precite)
      ),
    
    z_jif =
      as.numeric(
        scale(log_jif)
      ),
    
    z_OA =
      as.numeric(
        scale(OA_prop)
      ),
    
    z_Tpre =
      as.numeric(
        scale(log_Tpre)
      ),
    
    z_Ttotal =
      as.numeric(
        scale(log_Ttotal)
      )
  )


# ============================================================
# 13. Main model
# ============================================================
#
# T_pre:
# ordinary explanatory variable
#
# T_post:
# exposure time, entered as offset
#
# T_total:
# NOT entered simultaneously because it is exactly equal to
# T_pre + T_post.
#
# ============================================================

m_post <- glmmTMB(
  
  Postcite ~
    
    International *
    (
      z_Precite +
        z_jif +
        z_OA
    ) +
    
    z_Tpre +
    
    offset(
      log(T_post_years)
    ),
  
  family =
    truncated_nbinom2(
      link = "log"
    ),
  
  data = post_dat
)


# ============================================================
# 14. Model summary
# ============================================================

summary(m_post)


# ============================================================
# 15. Model diagnostics
# ============================================================

set.seed(123)

sim_post <- simulateResiduals(
  fittedModel = m_post,
  n = 1000
)

plot(sim_post)

print(
  testDispersion(
    sim_post
  )
)

print(
  testOutliers(
    sim_post
  )
)


# ============================================================
# 16. Extract coefficients
# ============================================================

model_result <- broom.mixed::tidy(
  
  m_post,
  
  effects = "fixed",
  
  conf.int = TRUE,
  
  conf.level = 0.95
)


# ============================================================
# 17. Convert beta to IRR
# ============================================================

model_result <- model_result %>%
  mutate(
    
    IRR =
      exp(estimate),
    
    CI_low =
      exp(conf.low),
    
    CI_high =
      exp(conf.high),
    
    Significance =
      case_when(
        
        p.value < 0.001 ~ "***",
        
        p.value < 0.01 ~ "**",
        
        p.value < 0.05 ~ "*",
        
        TRUE ~ ""
      )
  )


print(
  model_result %>%
    select(
      term,
      estimate,
      std.error,
      IRR,
      CI_low,
      CI_high,
      p.value,
      Significance
    )
)


# ============================================================
# 18. Main-effect table
# ============================================================

main_results <- model_result %>%
  filter(
    term %in% c(
      
      "InternationalInternational",
      
      "z_Precite",
      
      "z_jif",
      
      "z_OA",
      
      "z_Tpre"
    )
  ) %>%
  mutate(
    
    Predictor =
      case_when(
        
        term ==
          "InternationalInternational" ~
          "International collaboration",
        
        term ==
          "z_Precite" ~
          "Pre-retraction citations",
        
        term ==
          "z_jif" ~
          "Journal impact factor",
        
        term ==
          "z_OA" ~
          "Gold OA percentage",
        
        term ==
          "z_Tpre" ~
          "Publication-to-retraction time"
      )
  )


# ============================================================
# 19. Interaction table
# ============================================================

interaction_results <- model_result %>%
  filter(
    term %in% c(
      
      "InternationalInternational:z_Precite",
      
      "InternationalInternational:z_jif",
      
      "InternationalInternational:z_OA"
    )
  ) %>%
  mutate(
    
    Predictor =
      case_when(
        
        term ==
          "InternationalInternational:z_Precite" ~
          "International × Precite",
        
        term ==
          "InternationalInternational:z_jif" ~
          "International × JIF",
        
        term ==
          "InternationalInternational:z_OA" ~
          "International × Gold OA"
      )
  )


# ============================================================
# 20. Calculate effects of continuous predictors
#     specifically within International papers
# ============================================================
#
# For example:
#
# Precite effect in International papers
# =
# beta_Precite
# +
# beta_International:Precite
#
# ============================================================

vc <- vcov(m_post)$cond

b <- fixef(m_post)$cond


combined_effect <- function(main_term, interaction_term) {
  
  beta_combined <-
    b[main_term] +
    b[interaction_term]
  
  var_combined <-
    vc[main_term, main_term] +
    vc[interaction_term, interaction_term] +
    2 * vc[main_term, interaction_term]
  
  se_combined <-
    sqrt(var_combined)
  
  data.frame(
    
    beta =
      beta_combined,
    
    SE =
      se_combined,
    
    IRR =
      exp(beta_combined),
    
    CI_low =
      exp(
        beta_combined -
          1.96 * se_combined
      ),
    
    CI_high =
      exp(
        beta_combined +
          1.96 * se_combined
      )
  )
}


international_precite <-
  combined_effect(
    "z_Precite",
    "InternationalInternational:z_Precite"
  )

international_jif <-
  combined_effect(
    "z_jif",
    "InternationalInternational:z_jif"
  )

international_oa <-
  combined_effect(
    "z_OA",
    "InternationalInternational:z_OA"
  )


cat(
  "\nPrecite effect among International papers:\n"
)

print(international_precite)


cat(
  "\nJIF effect among International papers:\n"
)

print(international_jif)


cat(
  "\nGold OA effect among International papers:\n"
)

print(international_oa)


# ============================================================
# 21. Sensitivity analysis 1:
#     use pre-retraction citation rate
# ============================================================
#
# This avoids separating Precite and T_pre.
#
# It asks:
#
# Does citation velocity before retraction predict citation
# persistence after retraction?
# ============================================================

post_rate_dat <- post_dat %>%
  filter(
    T_pre_years > 0
  ) %>%
  mutate(
    
    PreCitationRate =
      Precite / T_pre_years,
    
    log_PreCitationRate =
      log1p(
        PreCitationRate
      ),
    
    z_PreCitationRate =
      as.numeric(
        scale(
          log_PreCitationRate
        )
      )
  )


m_rate <- glmmTMB(
  
  Postcite ~
    
    International *
    (
      z_PreCitationRate +
        z_jif +
        z_OA
    ) +
    
    offset(
      log(T_post_years)
    ),
  
  family =
    truncated_nbinom2(
      link = "log"
    ),
  
  data = post_rate_dat
)


summary(m_rate)


# ============================================================
# 22. Sensitivity analysis 2:
#     replace T_pre with T_total
# ============================================================
#
# This is only a sensitivity analysis.
#
# T_total is NOT included together with T_pre.
# ============================================================

m_total <- glmmTMB(
  
  Postcite ~
    
    International *
    (
      z_Precite +
        z_jif +
        z_OA
    ) +
    
    z_Ttotal +
    
    offset(
      log(T_post_years)
    ),
  
  family =
    truncated_nbinom2(
      link = "log"
    ),
  
  data = post_dat
)


summary(m_total)


# ============================================================
# 23. Prepare figure data
# ============================================================

main_results$Predictor <- factor(
  
  main_results$Predictor,
  
  levels = rev(
    c(
      "International collaboration",
      "Pre-retraction citations",
      "Journal impact factor",
      "Gold OA percentage",
      "Publication-to-retraction time"
    )
  )
)


interaction_results$Predictor <- factor(
  
  interaction_results$Predictor,
  
  levels = rev(
    c(
      "International × Precite",
      "International × JIF",
      "International × Gold OA"
    )
  )
)


# ============================================================
# 24. Main-effects figure
# ============================================================

p_main <- ggplot(
  
  main_results,
  
  aes(
    x = IRR,
    y = Predictor
  )
  
) +
  
  geom_vline(
    xintercept = 1,
    linetype = "dashed",
    linewidth = 0.5,
    colour = "grey45"
  ) +
  
  geom_errorbarh(
    aes(
      xmin = CI_low,
      xmax = CI_high
    ),
    height = 0.17,
    linewidth = 0.75,
    colour = "grey45"
  ) +
  
  geom_point(
    aes(
      fill = p.value < 0.05
    ),
    shape = 21,
    size = 4
  ) +
  
  scale_fill_manual(
    values = c(
      "TRUE" = "#377EB8",
      "FALSE" = "white"
    ),
    guide = "none"
  ) +
  
  geom_text(
    aes(
      x = CI_high * 1.04,
      label = Significance
    ),
    hjust = 0,
    size = 5
  ) +
  
  scale_x_log10() +
  
  theme_classic(
    base_size = 13
  ) +
  
  labs(
    title =
      "Main effects",
    
    x =
      "Incidence rate ratio (95% CI)",
    
    y = NULL
  )


# ============================================================
# 25. Interaction figure
# ============================================================

p_interaction <- ggplot(
  
  interaction_results,
  
  aes(
    x = IRR,
    y = Predictor
  )
  
) +
  
  geom_vline(
    xintercept = 1,
    linetype = "dashed",
    linewidth = 0.5,
    colour = "grey45"
  ) +
  
  geom_errorbarh(
    aes(
      xmin = CI_low,
      xmax = CI_high
    ),
    height = 0.17,
    linewidth = 0.75,
    colour = "grey45"
  ) +
  
  geom_point(
    aes(
      fill = p.value < 0.05
    ),
    shape = 21,
    size = 4
  ) +
  
  scale_fill_manual(
    values = c(
      "TRUE" = "#E41A1C",
      "FALSE" = "white"
    ),
    guide = "none"
  ) +
  
  geom_text(
    aes(
      x = CI_high * 1.04,
      label = Significance
    ),
    hjust = 0,
    size = 5
  ) +
  
  scale_x_log10() +
  
  theme_classic(
    base_size = 13
  ) +
  
  labs(
    title =
      "Interaction effects",
    
    x =
      "Interaction rate ratio (95% CI)",
    
    y = NULL
  )


# ============================================================
# 26. Combine figures
# ============================================================

final_plot <-
  p_main |
  p_interaction


final_plot <-
  final_plot +
  plot_annotation(
    
    title =
      "Factors associated with continued post-retraction citation",
    
    subtitle =
      paste0(
        "Post-retraction observation time was treated as exposure; ",
        "publication-to-retraction time was included as a covariate"
      )
  )


print(final_plot)


# ============================================================
# 27. Save figures
# ============================================================

ggsave(
  
  "Postcite_TimeAdjusted_Effects.png",
  
  final_plot,
  
  width = 13,
  
  height = 6,
  
  dpi = 600
)


ggsave(
  
  "Postcite_TimeAdjusted_Effects.pdf",
  
  final_plot,
  
  width = 13,
  
  height = 6
)


# ============================================================
# 28. Export model results
# ============================================================

write_xlsx(
  
  list(
    
    Descriptive_statistics =
      summary_all,
    
    By_International =
      summary_int,
    
    Main_effects =
      main_results %>%
      select(
        Predictor,
        estimate,
        std.error,
        IRR,
        CI_low,
        CI_high,
        p.value,
        Significance
      ),
    
    Interaction_effects =
      interaction_results %>%
      select(
        Predictor,
        estimate,
        std.error,
        IRR,
        CI_low,
        CI_high,
        p.value,
        Significance
      ),
    
    Full_model =
      model_result,
    
    International_Precite =
      international_precite,
    
    International_JIF =
      international_jif,
    
    International_OA =
      international_oa
  ),
  
  "Postcite_TimeAdjusted_Model_Results.xlsx"
)


cat(
  "\nAnalysis completed successfully.\n"
)