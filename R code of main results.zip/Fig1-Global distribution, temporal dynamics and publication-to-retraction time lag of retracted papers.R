

# ==========================================
# 针对美国国名匹配修复后的完整脚本
# ==========================================

library(readxl)
library(dplyr)
library(ggplot2)
library(sf)
library(rnaturalearth)
library(rnaturalearthdata)
library(gganimate)
library(gifski)
library(patchwork)
library(gridExtra)

# 1. 读取数据
data <- read_excel("D:/RCdata/RCdata_Cleaned_Final.xlsx")

# 【核心修复】：根据 world$name 的实际结果，将数据表中的 United States 转换为 United States of America
data <- data %>%
  mutate(Country_Primary_Cleaned = trimws(Country_Primary_Cleaned)) %>% # 去除前后空格
  mutate(Country_Primary_Cleaned = case_when(
    Country_Primary_Cleaned %in% c("United States", "USA", "United States of America", "U.S.", "U.S.A.") ~ "United States of America",
    Country_Primary_Cleaned %in% c("United Kingdom", "UK", "U.K.") ~ "United Kingdom",
    TRUE ~ Country_Primary_Cleaned
  ))

# 2. 获取全球地图的地理边界数据
world <- ne_countries(scale = "medium", returnclass = "sf")

# ------------------------------------------
# 任务一：统计各国家撤稿数量并绘制前20名柱状图
# ------------------------------------------
top20_countries <- data %>%
  filter(
    !is.na(Country_Primary_Cleaned), 
    Country_Primary_Cleaned != "",
    !tolower(Country_Primary_Cleaned) %in% c("unknown")
  ) %>% 
  group_by(Country_Primary_Cleaned) %>%
  summarise(Retraction_Count = n()) %>%
  arrange(desc(Retraction_Count)) %>%
  slice_max(order_by = Retraction_Count, n = 20)

p1 <- ggplot(top20_countries, aes(x = reorder(Country_Primary_Cleaned, Retraction_Count), y = Retraction_Count)) +
  geom_bar(stat = "identity", fill = "#4A76A8", width = 0.7) +
  # 【修改点 1】：减小柱子末端标签的字体大小 (从 3.5 减小到 2.5，更适合子图展示)
  geom_text(aes(label = Retraction_Count), hjust = -0.15, size = 2.5, color = "black") +
  coord_flip() +
  # 【修改点 2】：核心！通过 mult = c(0, 0.12) 在长柱子右侧强行留出 12% 的空白缓冲区域，确保中国顶部的数字 100% 露出来
  scale_y_continuous(expand = expansion(mult = c(0, 0.12))) + 
  theme_minimal(base_family = "SimSun") +
  labs(
    title = "Top 20 Countries/Regions of Retractions", 
    x = "国家/地区", 
    y = "撤稿总量"
  ) +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    panel.grid.minor = element_blank()
  )

# ------------------------------------------
# 任务二：绘制每年撤稿数量的柱状图
# ------------------------------------------
# ==========================================
# 任务二（升级版）：含统计表格与滞后阴影的历年撤稿图
# ========================================================
# 终极修复版：防御性编程，确保 stats_table_grob 100% 生成
# ========================================================
# ========================================================
# 兼容性排错版：修正 gridExtra 参数并强制创建表格
# ========================================================

library(ggplot2)
library(dplyr)
library(gridExtra)

# 1. 安全清洗与转换数据
data_clean <- data %>%
  mutate(
    Time_to_Retraction = as.numeric(as.character(Time_to_Retraction)),
    PubYear = as.numeric(as.character(PubYear)),
    RetYear = as.numeric(as.character(RetYear))
  )

# 2. 计算统计指标（增加防御性判断，防止 NaN 崩溃）
val_all <- mean(data_clean$Time_to_Retraction, na.rm = TRUE)
if (is.nan(val_all)) val_all <- 0  

sub_18_22 <- data_clean %>% 
  filter(PubYear >= 2018 & PubYear <= 2022 & !is.na(Time_to_Retraction))
val_18_22 <- if(nrow(sub_18_22) > 0) mean(sub_18_22$Time_to_Retraction) else 0

val_max <- max(data_clean$Time_to_Retraction, na.rm = TRUE)
if (is.infinite(val_max) || is.na(val_max)) val_max <- 0

# 3. 构建数据框
stats_df <- data.frame(
  `DATASET TIME-LAG STATISTICS` = c("Avg. Time_to_Retract (all)", "Avg. Time_to_Retract (18-22)", "Max. Lag Observed"),
  `VALUE` = c(paste0(round(val_all, 2), " yrs"), paste0(round(val_18_22, 2), " yrs"), paste0(round(val_max, 2), " yrs")),
  check.names = FALSE
)

# 4. 【核心修复】：将原先的 size 改为符合新版标准的 fontsize
table_theme <- ttheme_default(
  core = list(bg_params = list(fill = c("#F2F2F2", "#FFFFFF", "#F2F2F2"), col = NA),
              fg_params = list(fontface = 1, hjust = 0, x = 0.05, fontsize = 9)), # 已修正为 fontsize
  colhead = list(bg_params = list(fill = "#333333"),
                 fg_params = list(col = "white", fontface = "bold", hjust = 0, x = 0.05, fontsize = 9)) # 已修正为 fontsize
)

# 5. 生成 Grob 对象
stats_table_grob <- tableGrob(stats_df, rows = NULL, theme = table_theme)

# 6. 统计历年撤稿数量
annual_retractions <- data_clean %>%
  filter(!is.na(RetYear)) %>%
  group_by(RetYear) %>%
  summarise(Retraction_Count = n(), .groups = 'drop') %>%
  arrange(RetYear)

# 7. 开始绘图
p2 <- ggplot(annual_retractions, aes(x = RetYear, y = Retraction_Count)) +
  # 绘制右侧灰色滞后阴影区
  annotate("rect", xmin = 2023, xmax = 2026.5, ymin = 0, ymax = max(annual_retractions$Retraction_Count) * 1.05,
           fill = "#7F7F7F", alpha = 0.15) +
  
  # 添加阴影区的垂直文本说明
  annotate("text", x = 2023.8, y = max(annual_retractions$Retraction_Count) * 0.4, 
           label = paste0("Time-Lag Truncation Window\n(Driven by Mean Time_to_Retraction = ", round(val_18_22, 2), " Years)"),
           angle = 90, color = "#404040", fontface = "italic", size = 3.5, hjust = 0.5) +
  
  # 绘制核心主图柱状图
  geom_bar(stat = "identity", fill = "#C0504D", width = 0.7) +
  
  # 嵌入修正后的左上角小表
  annotation_custom(
    grob = stats_table_grob, 
    xmin = min(annual_retractions$RetYear), 
    xmax = min(annual_retractions$RetYear) + 25, 
    ymin = max(annual_retractions$Retraction_Count) * 0.65, 
    ymax = max(annual_retractions$Retraction_Count) * 0.98
  ) +
  
  scale_x_continuous(breaks = seq(min(annual_retractions$RetYear), max(annual_retractions$RetYear), by = 2)) +
  theme_minimal(base_family = "SimSun") +
  labs(title = "历年全球撤稿数量分布图", x = "撤稿年份", y = "撤稿数量") +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 9),
    panel.grid.minor = element_blank()
  )

# 8. 保存输出
ggsave("annual_retractions_with_panel.png", plot = p2_upgraded, width = 12, height = 7, dpi = 300)
print("图表安全编译成功，并已成功导出！")

# ------------------------------------------
# 任务三：绘制全球各个国家撤稿数量的热力分布总图（已适配地图字段）
# ------------------------------------------
total_country_counts <- data %>%
  filter(!is.na(Country_Primary_Cleaned), Country_Primary_Cleaned != "") %>%
  group_by(Country_Primary_Cleaned) %>%
  summarise(Total_Retractions = n())

# 使用通过 case_when 映射好的名字与 world$name 进行完美匹配
world_map_total <- world %>%
  left_join(total_country_counts, by = c("name" = "Country_Primary_Cleaned"))

library(scales)

p3 <- ggplot(data = world_map_total) +
  geom_sf(aes(fill = Total_Retractions), color = "white", size = 0.1) +
  scale_fill_viridis_c(
    option = "plasma", 
    na.value = "#EAEAEA", 
    name = "Retractions",
    trans = "log10",
    # 【核心改进】：强制图例按对数标准分级显示标签
    breaks = scales::log_breaks(n = 5), 
    labels = scales::label_comma() # 保持数字格式正常（去除科学计数法）
  ) +
  theme_minimal(base_family = "SimSun") +
  labs(
    title = "Global Distribution of Retractions",
    subtitle = "灰色区域代表无数据或数量为零"
  ) +
  theme(
    plot.title = element_text(face = "bold", size = 14, hjust = 0.5),
    plot.subtitle = element_text(size = 10, hjust = 0.5, color = "gray30"),
    legend.position = "bottom",
    # 让图例色条稍微拉长一点，方便看清过渡
    legend.key.width = unit(2, "cm") 
  )

# ------------------------------------------
# 任务四：动态GIF更新
# ------------------------------------------
all_years <- unique(data$RetYear[!is.na(data$RetYear)])
all_countries <- unique(data$Country_Primary_Cleaned[!is.na(data$Country_Primary_Cleaned)])
full_grid <- expand.grid(Country_Primary_Cleaned = all_countries, RetYear = all_years)

yearly_country_counts <- data %>%
  filter(!is.na(Country_Primary_Cleaned), !is.na(RetYear)) %>%
  group_by(Country_Primary_Cleaned, RetYear) %>%
  summarise(Retractions = n(), .groups = 'drop') %>%
  right_join(full_grid, by = c("Country_Primary_Cleaned", "RetYear")) %>%
  mutate(Retractions = ifelse(is.na(Retractions), 0, Retractions))

# 默认筛选 2000 年之后的数据
yearly_country_counts <- yearly_country_counts %>% filter(RetYear >= 1990)

world_animated_data <- world %>%
  cross_join(data.frame(RetYear = unique(yearly_country_counts$RetYear))) %>%
  left_join(yearly_country_counts, by = c("name" = "Country_Primary_Cleaned", "RetYear" = "RetYear")) %>%
  mutate(Retractions = ifelse(is.na(Retractions), 0, Retractions))

p_anim <- ggplot(data = world_animated_data) +
  geom_sf(aes(fill = Retractions), color = "white", size = 0.1) +
  scale_fill_gradientn(
    colors = c("#EAEAEA", "#FDD49E", "#FDBB84", "#FC8D59", "#EF6548", "#D7301F", "#7F0000"),
    values = c(0, 0.01, 0.05, 0.1, 0.3, 0.6, 1),
    name = "当年撤稿数"
  ) +
  theme_minimal(base_family = "SimSun") +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5),
    legend.position = "bottom"
  ) +
  labs(title = "Annual dynamics of global retractions: {current_frame}") +
  transition_manual(RetYear)

num_years <- length(unique(world_animated_data$RetYear))
animate(
  p_anim, 
  nframes = num_years, 
  fps = 2, 
  width = 1000, 
  height = 500, 
  renderer = gifski_renderer("global_retractions_annually.gif")
)

print("针对美国名称修复后的图表及GIF动图已成功重新生成！")
# ==========================================
# 使用 patchwork 将 p1 和 p3 作为子图嵌入 p2 的左上方
# ==========================================

# 1. 调整 p1 和 p3 的主题样式，使其作为子图时更紧凑、美观
# 去掉子图不必要的背景或冗余标签，防止画面过于拥挤
p1_mini <- p1 + 
  theme_minimal(base_family = "SimSun", base_size = 7) + # 调小字号
  labs(title = "Top 20 Countries/Regions of Retractions", x = NULL, y = NULL) +   # 简化标题
  theme(plot.title = element_text(size = 10, face = "bold"))

p3_mini <- p3 + 
  theme_minimal(base_family = "SimSun", base_size = 9) +
  labs(title = "Global Retraction distribution", subtitle = NULL) +     # 移除副标题
  theme(
    plot.title = element_text(size = 10, face = "bold"),
    legend.position = "bottom",                           # 将图例移到右侧省空间
    legend.key.width = unit(0.3, "cm"),
    legend.key.height = unit(0.3, "cm")
  )

# 2. 将 p1_mini 和 p3_mini 嵌入到主图 p2 的左侧空白区域
# inset_element 的参数含义: left, bottom, right, top (取值范围 0 到 1，代表主图画布的比例位置)
p_combined <- p2 +
  # 嵌入地图 (放在极左上角)
  inset_element(
    p3_mini, 
    left = 0.02,   # 紧贴左边缘
    bottom = 0.45, # 位于中上部
    right = 0.50,  # 占据横向左半边
    top = 0.98     # 紧贴上边缘
  ) +
  # 嵌入国家柱状图 (放在地图下方，但仍在左侧空白区)
  inset_element(
    p1_mini, 
    left = 0.02,   # 紧贴左边缘
    bottom = 0.05, # 位于主图底部上方一点
    right = 0.45,  # 占据横向左半边
    top = 0.43     # 刚好在地图下方
  )

# 3. 保存组合后的高分辨率大图
# 因为容纳了三个图，建议将画布调宽、调高（例如 width = 16, height = 10）
ggsave("combined_retraction_dashboard.png", plot = p_combined, width = 16, height = 10, dpi = 600)


# ========================================================
# 针对超宽仪表盘优化的主图与子图组合脚本
# ========================================================
# ========================================================
# 仪表盘终极版：添加指示箭头并将 Time-lag 说明移至表格下方
# ========================================================

library(ggplot2)
library(dplyr)
library(gridExtra)
library(patchwork)

# 1. 数据安全清洗与转换
data_clean <- data %>%
  mutate(
    Time_to_Retraction = as.numeric(as.character(Time_to_Retraction)),
    PubYear = as.numeric(as.character(PubYear)),
    RetYear = as.numeric(as.character(RetYear))
  )

val_all   <- mean(data_clean$Time_to_Retraction, na.rm = TRUE)
sub_18_22 <- data_clean %>% filter(PubYear >= 2018 & PubYear <= 2022 & !is.na(Time_to_Retraction))
val_18_22 <- if(nrow(sub_18_22) > 0) mean(sub_18_22$Time_to_Retraction) else 0
val_max   <- max(data_clean$Time_to_Retraction, na.rm = TRUE)

# 2. 构建左上角统计数据框与 Grob 对象
stats_df <- data.frame(
  `DATASET TIME-LAG STATISTICS` = c("Avg. Time_to_Retract (all)", "Avg. Time_to_Retract (18-22)", "Max. Lag Observed"),
  `VALUE` = c(paste0(round(val_all, 2), " yrs"), paste0(round(val_18_22, 2), " yrs"), paste0(round(val_max, 2), " yrs")),
  check.names = FALSE
)

table_theme <- ttheme_default(
  core = list(bg_params = list(fill = c("#F2F2F2", "#FFFFFF", "#F2F2F2"), col = NA),
              fg_params = list(fontface = 1, hjust = 0, x = 0.05, fontsize = 9)),
  colhead = list(bg_params = list(fill = "#333333"),
                 fg_params = list(col = "white", fontface = "bold", hjust = 0, x = 0.05, fontsize = 9))
)
stats_table_grob <- tableGrob(stats_df, rows = NULL, theme = table_theme)

# 3. 统计历年撤稿数量
annual_retractions <- data_clean %>%
  filter(!is.na(RetYear)) %>%
  group_by(RetYear) %>%
  summarise(Retraction_Count = n(), .groups = 'drop') %>%
  arrange(RetYear)

max_y_val <- max(annual_retractions$Retraction_Count)

# 4. 重新定制大图主背景 p2_upgraded
p2_upgraded <- ggplot(annual_retractions, aes(x = RetYear, y = Retraction_Count)) +
  # 绘制右侧灰色滞后阴影区
  annotate("rect", xmin = 2023, xmax = 2026.5, ymin = 0, ymax = max_y_val * 1.05,
           fill = "#7F7F7F", alpha = 0.15) +
  
  # 【方案改进】：在表格下方的空白高处（X=2008, Y= max*0.62 左右）放置注释文本
  annotate("text", x = 1986, y = max_y_val * 0.58, 
           label = paste0("* Note: The Time-Lag Truncation Window is driven by\n  Mean Time_to_Retraction (18-22) = ", round(val_18_22, 2), " Years."),
           color = "#404040", fontface = "italic", size = 3.2, hjust = 0) +
  
  # 【拉引线与箭头】：从右侧阴影区（X=2024）拉一根带箭头的横线指向刚才的说明文字
  annotate("segment", x = 2023.5, xend = 2018, y = max_y_val * 0.58, yend = max_y_val * 0.58,
           color = "#555555", size = 0.5, arrow = arrow(length = unit(0.2, "cm"))) +
  
  # 在阴影带上方加一个非常精简干净的垂直短标签
  annotate("text", x = 2024.8, y = max_y_val * 0.85, 
           label = "Time-Lag Window", angle = 90, color = "#555555", fontface = "bold", size = 3.2) +
  
  geom_bar(stat = "identity", fill = "#C0504D", width = 0.7) +
  
  # 嵌入面板表格 (放置于中间靠右空白高处)
  annotation_custom(
    grob = stats_table_grob, 
    xmin = 1996, 
    xmax = 2018, 
    ymin = max_y_val * 0.66, 
    ymax = max_y_val * 0.96
  ) +
  scale_y_continuous(position = "right") +
  scale_x_continuous(breaks = seq(min(annual_retractions$RetYear), max(annual_retractions$RetYear), by = 2)) +
  theme_minimal(base_family = "SimSun") +
  labs(title = "", x = "Year", y = "Retracted papers") +
  theme(
    plot.title = element_text(face = "bold", size = 16, hjust = 0.5, vjust = 2),
    axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1, size = 9),
    panel.grid.minor = element_blank()
  )

# 5. 子图配置（保持白色背景阻挡主图网格线）
p1_mini <- p1 + 
  theme_minimal(base_family = "SimSun", base_size = 9) + 
  labs(title = "Top 20 Countries/Regions of Retractions", x = NULL, y = NULL) + 
  theme(plot.title = element_text(size = 11, face = "bold"),
        panel.background = element_rect(fill = "white", color = NA))

p3_mini <- p3 + 
  theme_minimal(base_family = "SimSun", base_size = 9) +
  labs(title = "Global Retraction distribution", subtitle = NULL) + 
  theme(
    plot.title = element_text(size = 11, face = "bold"),
    legend.position = "bottom",
    legend.key.width = unit(0.4, "cm"),
    legend.key.height = unit(0.3, "cm"),
    panel.background = element_rect(fill = "white", color = NA)
  )

# 6. 使用 patchwork 完美拼版
p_combined <- p2_upgraded +
  inset_element(p3_mini, left = 0.1, bottom = 0.52, right = 0.48, top = 0.96) +
  inset_element(p1_mini, left = 0.01, bottom = 0.08, right = 0.48, top = 0.50)

p_combined 
# 7. 导出最终图片
ggsave("D:/combined_retraction_dashboard_final.pdf", plot = p_combined, width = 18, height = 9, dpi = 300)
print("完美排版、带注释箭头的仪表盘图表已成功导出！")
library(Cairo)

# ========================================================
# 导出矢量 PDF 到 D 盘指定文件夹
# ========================================================
# ========================================================
# CDR 专项适配版：使用原生 pdf 驱动并剔除字体干扰
# ========================================================
# ========================================================
# 导出矢量 PDF 到 D 盘指定文件夹
# ========================================================

# 1. 加载 Cairo 包
library(Cairo)

# 2. 打开 Cairo PDF 设备，并指定 D 盘的绝对路径
# 注意：路径中请使用正斜杠 "/"
CairoPDF(
  file = "D:/RCdata/zuhe.pdf", 
  width = 18, 
  height = 9, 
  family = "SimSun"
) 

# 3. 在设备中打印你的最终拼版对象
print(p_combined)

# 4. 关闭设备，完成文件写入并保存到 D:/RCdata/
dev.off()

# ========================================================
# Cairo 兼容 CDR 2020 专属导出脚本
# ========================================================

library(Cairo)
library(ggplot2)

# 1. 稍微加一点画布边距留白，防止矢量节点贴边
p_combined_cdr <- p_combined + theme(plot.margin = margin(0.2, 0.2, 0.2, 0.2, "in"))

# 2. 启动 Cairo 优化配置
CairoPDF(
  file = "D:/RCdata/zuhe2.pdf", 
  width = 18, 
  height = 9, 
  family = "SimSun",       # 指定标准中文字体
  version = "1.4",         # 核心关键 1：将 PDF 版本强行降到 1.4（CDR 2020 解析高版本极易崩溃）
  bg = "transparent"       # 保持背景透明，方便 CDR 抠图美化
)

# 3. 核心关键 2：通过 R 的底层选项，彻底关闭 Dingbats 特殊符号
# 很多时候 Cairo 报错损坏就是因为偷偷写入了 CDR 无法识别的数学/图形符号编码
options(useDingbats = FALSE)

# 4. 打印图表到设备
print(p_combined_cdr)

# 5. 关闭设备，完整写入磁盘
dev.off()

print("Cairo-CDR2020 兼容版 PDF 已导出成功！")

