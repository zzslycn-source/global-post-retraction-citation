# ==============================================================================
# 撤稿效力 (ARR) 全样本总体占比与显著性标注趋势图脚本
# 数据路径: D:/RCdata
# ==============================================================================

# 1. 自动检查并载入所需的包
required_packages <- c("tidyverse", "readxl", "Kendall", "scales")
for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

setwd("D:/RCdata")

# 2. 导入并清洗数据 ------------------------------------------------------------
cat("正在导入并清洗全样本数据...\n")
raw_main <- read_excel("20260705.xlsx")

df_all_types <- raw_main %>%
  mutate(
    RetY = as.numeric(RetY),
    ARR = as.numeric(ARR),
    ARR_Group = case_when(
      ARR == 0            ~ "完全阻止 (ARR = 0)",
      ARR > 0 & ARR <= 1  ~ "部分阻止 (0 < ARR <= 1)",
      ARR > 1            ~ "完全失效 (ARR > 1)",
      TRUE                ~ NA_character_
    )
  ) %>%
  filter(!is.na(ARR_Group) & !is.na(RetY))

# 确保图例顺序
df_all_types$ARR_Group <- factor(
  df_all_types$ARR_Group, 
  levels = c("完全阻止 (ARR = 0)", "部分阻止 (0 < ARR <= 1)", "完全失效 (ARR > 1)")
)

# 3. 补充补充：全样本总体占比统计与绘制 ----------------------------------------
cat("\n--- 1. 正在计算并绘制全局总体占比环形图 ---\n")

overall_summary <- df_all_types %>%
  count(ARR_Group) %>%
  mutate(
    Percentage = n / sum(n) * 100,
    label = paste0(ARR_Group, "\n", round(Percentage, 2), "% (", comma(n), " 篇)")
  )

# 绘制漂亮的全局占比环形图
p_pie <- ggplot(overall_summary, aes(x = 2, y = Percentage, fill = ARR_Group)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar(theta = "y", start = 0) +
  xlim(0.5, 2.5) + # 变为环形图，留出中心空白
  geom_text(aes(label = label), position = position_stack(vjust = 0.5), size = 4.2, fontface = "bold", color = "white") +
  scale_fill_manual(values = c("完全阻止 (ARR = 0)" = "#2ca02c",      
                               "部分阻止 (0 < ARR <= 1)" = "#ff7f0e",  
                               "完全失效 (ARR > 1)" = "#d62728")) +
  labs(title = "全局撤稿阻断效力 (ARR) 总体占比分布",
       subtitle = paste0("总计有效观测样本：", comma(nrow(df_all_types)), " 篇")) +
  theme_void() +
  theme(
    legend.position = "none", # 标签已在图上，不需要图例
    plot.title = element_text(face = "bold", hjust = 0.5, size = 15),
    plot.subtitle = element_text(hjust = 0.5, size = 11, color = "gray30")
  )

ggsave("ARR_Overall_Distribution_Pie.png", plot = p_pie, width = 7, height = 7, dpi = 300)


# 4. 按年份计算年度百分比并进行时序检验 ---------------------------------------
yearly_ratio <- df_all_types %>%
  group_by(RetY, ARR_Group) %>%
  summarise(Count = n(), .groups = "drop_last") %>%
  mutate(Percentage = Count / sum(Count) * 100) %>%
  ungroup() %>%
  arrange(RetY)

wide_ts <- yearly_ratio %>%
  select(RetY, ARR_Group, Percentage) %>%
  pivot_wider(names_from = ARR_Group, values_from = Percentage, values_fill = 0) %>%
  arrange(RetY)

# 执行 Mann-Kendall 检验
mk1 <- MannKendall(wide_ts$`完全阻止 (ARR = 0)`)
mk2 <- MannKendall(wide_ts$`部分阻止 (0 < ARR <= 1)`)
mk3 <- MannKendall(wide_ts$`完全失效 (ARR > 1)`)


# 5. 构建动态显著性文本标签 --------------------------------------------------
# 格式化学术常用的 p 值展示格式
format_p <- function(p) { if(p < 0.001) "p < 0.001 ***" else if(p < 0.01) paste0("p = ", round(p,3), " **") else if(p < 0.05) paste0("p = ", round(p,3), " *") else paste0("p = ", round(p,3), " (不显著)") }

text_anno <- paste0(
  "【趋势显著性检验结果 (Mann-Kendall)】\n",
  "● 完全阻止 (绿): Tau = ", round(mk1$tau[1], 3), ", ", format_p(mk1$sl[1]), "\n",
  "● 部分阻止 (橙): Tau = ", round(mk2$tau[1], 3), ", ", format_p(mk2$sl[1]), "\n",
  "● 完全失效 (红): Tau = ", round(mk3$tau[1], 3), ", ", format_p(mk3$sl[1])
)


# 6. 绘制带有显著性标注的趋势图 -----------------------------------------------
cat("\n--- 2. 正在生成带有显著性标注的趋势图 ---\n")

min_year <- min(wide_ts$RetY)
max_year <- max(wide_ts$RetY)

p_trend <- ggplot(yearly_ratio, aes(x = RetY, y = Percentage, color = ARR_Group, group = ARR_Group)) +
  geom_point(size = 2, alpha = 0.4) +
  geom_smooth(method = "loess", se = TRUE, size = 1.2, alpha = 0.1) +
  scale_color_manual(values = c("完全阻止 (ARR = 0)" = "#2ca02c",      
                                "部分阻止 (0 < ARR <= 1)" = "#ff7f0e",  
                                "完全失效 (ARR > 1)" = "#d62728")) +    
  scale_x_continuous(breaks = seq(min_year, max_year, by = 5)) +
  
  # 【核心升级】：在图表的左上角空白区域动态添加统计学检验文本框
  annotate(
    "label", 
    x = min_year + 6, # X轴起始靠左位置
    y = 100,           # Y轴靠上的空白位置
    label = text_anno, 
    hjust = 0,        # 左对齐
    vjust = 1, 
    size = 4, 
    fill = "#fdfdfd", 
    color = "black", 
    label.padding = unit(0.5, "lines")
  ) +
  
  labs(
        x = "Retraction Year",
    y = "Proportions of retraction with differeng ARR (%)",
    color = "撤稿阻断效力"
  ) +
  theme_minimal(base_size = 13) +
  theme(
    legend.position = "bottom",
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 15),
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1)
  )

# 保存最终图表
ggsave("ARR_Global_Time_Trend_With_Significance.png", plot = p_trend, width = 11, height = 7, dpi = 300)
cat("\n升级版分析图已成功保存至 D:/RCdata/\n")

